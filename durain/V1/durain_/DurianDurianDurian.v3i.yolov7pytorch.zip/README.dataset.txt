# DurianDurianDurian > 2023-06-29 12:17am
https://universe.roboflow.com/jin-cced3/durianduriandurian

Provided by a Roboflow user
License: Public Domain

