# DurianDurianDurian > 2023-06-28 9:16pm
https://universe.roboflow.com/jin-cced3/durianduriandurian

Provided by a Roboflow user
License: Public Domain

