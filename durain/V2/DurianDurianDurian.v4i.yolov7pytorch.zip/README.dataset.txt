# DurianDurianDurian > 2023-07-02 3:16pm
https://universe.roboflow.com/jin-cced3/durianduriandurian

Provided by a Roboflow user
License: Public Domain

